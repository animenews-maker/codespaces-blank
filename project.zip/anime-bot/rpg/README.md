# RPG & Mini-Games

For v20+ features: Full RPG system, multiplayer, guilds, quests, and seasonal events.
