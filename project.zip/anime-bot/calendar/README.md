# Calendar System

Visual seasonal calendar, real-time episode tracking, and dashboard integration for v13+ features.
