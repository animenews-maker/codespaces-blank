# Watchlist System

Tracks user anime watchlists, syncs with AniList/MAL, and supports Notion export. Used for v12+ features.
