# Memory System

This folder stores per-user memory files (user preferences, quiz results, search history, etc.) for Anime Autopilot Bot v7.0.
- Each user gets a `user_<id>.json` file.
- Used for personalized recommendations and AI assistant mode.
