# Anime Lore Encyclopedia

For v22+ features: Lore database, timelines, trivia, and AI-powered lorekeeper.
