# Mobile Companion App

For v24+ features: Push notifications, offline mode, AR, and voice assistant.
