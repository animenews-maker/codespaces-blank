# VR & Metaverse Integration

For v17+ features: VRChat, Horizon Worlds, virtual watch parties, 3D avatars, and live events.
