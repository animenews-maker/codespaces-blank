# Voice Module

Contains TTS voice settings and logic for Anime Autopilot Bot v7.0.
- `voices.json`: Maps character names to TTS voices.
- Add TTS/voice fetch/play logic in this module.
