# Discord bot package init
