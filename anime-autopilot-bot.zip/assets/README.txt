This folder contains static assets such as fonts, logos, and images for the Anime Autopilot Bot.
