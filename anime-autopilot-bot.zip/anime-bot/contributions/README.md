# Contributions & Learning

This folder tracks user contributions, corrections, and AI learning data for Anime Autopilot Bot v7.0.
- Suggestions, corrections, and genre training are stored here.
- Used for community-driven improvements and stats.
