# Anime Lore Encyclopedia module
