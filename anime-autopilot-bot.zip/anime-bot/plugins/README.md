# Plugin & Customization System

For v23+ features: Custom commands, plugin marketplace, API access, and server tweaks.
