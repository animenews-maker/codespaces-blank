# VR Anime RPG World

For v29+ features: Full VR RPG, avatars, quests, battles, and real-time events.
