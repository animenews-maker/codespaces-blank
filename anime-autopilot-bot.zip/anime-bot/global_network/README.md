# Global Anime Community Network

For v25+ features: Federated social network, user profiles, reviews, and server-to-server events.
