# Native Mobile Anime Bot App

For v33+ features: Standalone app, push notifications, voice commands, and offline sync.
