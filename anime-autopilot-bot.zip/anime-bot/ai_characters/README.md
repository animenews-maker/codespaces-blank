# AI Character Dialogue & Roleplay

For v18+ features: NLP dialogue, evolving personalities, roleplay NPCs, and emotional voice acting.
