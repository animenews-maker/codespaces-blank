# Advanced Moderation AI

For v31+ features: Spam/toxicity detection, auto-moderation, sentiment filtering, and mod dashboard.
